#!/bin/bash
DIRNAME=$(pwd)
export LD_LIBRARY_PATH=$DIRNAME/lib
./airstrike $1 $2 $3 $4
