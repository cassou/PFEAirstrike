#!/bin/bash
DIRNAME=$(pwd)
export LD_LIBRARY_PATH=$DIRNAME/lib
./bin/QtClient